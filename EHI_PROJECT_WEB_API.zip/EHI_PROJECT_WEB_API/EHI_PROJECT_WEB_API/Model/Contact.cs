﻿using EHI_PROJECT_WEB_API.Data;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EHI_PROJECT_WEB_API.Model
{
    public class Contact
    {

        #region Constructors

        public Contact()
        {

        }

        #endregion


        /// <summary>
        /// Identifier
        /// </summary>
        public Guid? Id { get; set; }

        /// <summary>
        /// First Name of the Contact
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Last Name Of The Contact
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Email of The contact
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Status of the Contact
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        /// Is Deleted Flag of the contact
        /// </summary>
        public bool IsDeleted { get; set; }

        /// <summary>
        /// Discription
        /// </summary>
        public string Discription { get; set; }


        /// <summary>
        /// Get All Contact List
        /// </summary>
        /// <returns></returns>
        internal async Task<IList<Contact>> GetAllContacts()
        {
            ContactDataReaderWriter dataAccessor = new ContactDataReaderWriter();
            List<Contact> contacts = JsonConvert.DeserializeObject<List<Contact>>(dataAccessor.Read("ContactData.json", "Data"));
            return await Task.FromResult(contacts.Where(c => !c.IsDeleted && c.IsActive).ToList());
        }

        /// <summary>
        /// Save/ Update Contact
        /// </summary>
        /// <returns></returns>
        internal async Task<BaseViewModel> Save()
        {
            ContactDataReaderWriter dataAccessor = new ContactDataReaderWriter();
            List<Contact> contacts = JsonConvert.DeserializeObject<List<Contact>>(dataAccessor.Read("ContactData.json", "Data"));

            if (contacts == null)
            {
                contacts = new List<Contact>();
            }

            // add to collection
            contacts.Add(new Contact() { Id = Id, FirstName = FirstName, LastName = LastName, Discription = Discription, Email = Email, IsDeleted = IsDeleted, IsActive = IsActive });

            // write to json
            string contactJson = JsonConvert.SerializeObject(contacts);
            dataAccessor.Write("ContactData.json", "Data", contactJson);

            BaseViewModel baseViewModel = new BaseViewModel() { Id = Id, Message = "Record Added sucessfully" };
            return await Task.FromResult(baseViewModel);
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <returns></returns>
        internal async Task<BaseViewModel> Update()
        {
            BaseViewModel baseViewModel = new BaseViewModel();
            ContactDataReaderWriter dataAccessor = new ContactDataReaderWriter();
            List<Contact> contacts = JsonConvert.DeserializeObject<List<Contact>>(dataAccessor.Read("ContactData.json", "Data"));


            contacts = contacts ?? (contacts = new List<Contact>());

            // find by id and update record
            int index = contacts.FindIndex(c => c.Id == Id && !c.IsDeleted && c.IsActive);
            if (index < 0)
            {
                baseViewModel.Id = Id;
                baseViewModel.Message = "Record Not Found";
            }
            else
            {
                contacts[index].FirstName = FirstName;
                contacts[index].LastName = LastName;
                contacts[index].Discription = Discription;
                contacts[index].Email = Email;
                contacts[index].IsActive = IsActive;
                contacts[index].IsDeleted = IsDeleted;

                // write to json
                string contactJson = JsonConvert.SerializeObject(contacts);
                dataAccessor.Write("ContactData.json", "Data", contactJson);

                baseViewModel = new BaseViewModel() { Id = Id, Message = "Record updated sucessfully" };
            }

            return await Task.FromResult(baseViewModel);
        }

        /// <summary>
        /// Delete existing contact information
        /// </summary>
        /// <param name="id">unique identifier code</param>
        /// <returns>Is delete flag</returns>
        internal async Task<BaseViewModel> DeleteContact(BaseViewModel baseViewModel)
        {
            ContactDataReaderWriter dataAccessor = new ContactDataReaderWriter();
            List<Contact> contacts = JsonConvert.DeserializeObject<List<Contact>>(dataAccessor.Read("ContactData.json", "Data"));

            // find by id and remove record
            int index = contacts.FindIndex(c => c.Id == Id && !c.IsDeleted && c.IsActive);

            if (index < 0)
            {
                baseViewModel.Message = "Record Not Found";
            }
            else
            {
                contacts[index].IsDeleted = true;
                contacts[index].IsActive = false;

                // write to json
                string contactJson = JsonConvert.SerializeObject(contacts);
                dataAccessor.Write("ContactData.json", "Data", contactJson);

                baseViewModel.Message = "Record deleted sucessfully";
            }

            return await Task.FromResult(baseViewModel);

        }
    }
}
