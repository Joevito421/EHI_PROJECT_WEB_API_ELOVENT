﻿using EHI_PROJECT_WEB_API.Model;
using EHI_PROJECT_WEB_API.ViewModel;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EHI_PROJECT_WEB_API.Services
{
    public interface IContactService
    {
        /// <summary>
        /// Create New Contact
        /// </summary>
        /// <returns></returns>
        Task<BaseViewModel> AddContact(ContactViewModel contactViewModel);

        /// <summary>
        /// Edit New Contact
        /// </summary>
        /// <returns></returns>
        Task<BaseViewModel> EditContact(ContactViewModel contactViewModel);

        /// <summary>
        /// Get All Contact List
        /// </summary>
        /// <returns></returns>
        Task<IList<Contact>> GetAllContacts();

        /// <summary>
        /// Get Contact By Identifier
        /// </summary>
        /// <returns></returns>
        Task<Contact> GetContactById(Guid id);

        /// <summary>
        /// Delete Contact
        /// </summary>
        /// <param name="viewModel">viewModel</param>
        /// <returns>Base View Model</returns>
        Task<BaseViewModel> DeleteContact(BaseViewModel viewModel);
    }
}
