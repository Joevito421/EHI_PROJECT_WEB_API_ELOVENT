﻿namespace EHI_PROJECT_WEB_API.ViewModel
{
    public class ContactViewModel : BaseViewModel
    {

        /// <summary>
        /// First Name of the Contact
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Last Name Of The Contact
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Email of The contact
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Contact Number
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// Status of the Contact
        /// </summary>
        public bool IsActive { get; set; } = true;

        /// <summary>
        /// Is Deleted Flag of the contact
        /// </summary>
        public bool IsDeleted { get; set; } = false;

        /// <summary>
        /// Discription
        /// </summary>
        public string Discription { get; set; }
    }
}
