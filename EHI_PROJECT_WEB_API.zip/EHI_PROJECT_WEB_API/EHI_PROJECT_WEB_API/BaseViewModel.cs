﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EHI_PROJECT_WEB_API
{
    public class BaseViewModel
    {
        /// <summary>
        /// Identifier
        /// </summary>
        public Guid? Id { get; set; }

        /// <summary>
        /// Message
        /// </summary>
        public string Message { get; set; }
    }
}
