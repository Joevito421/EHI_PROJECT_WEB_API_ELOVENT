﻿using EHI_PROJECT_WEB_API.Model;
using EHI_PROJECT_WEB_API.Services;
using EHI_PROJECT_WEB_API.ViewModel;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EHI_PROJECT_WEB_API.Logic
{
    public class ContactService : IContactService
    {

        public ContactService()
        {

        }

        /// <summary>
        /// Add Contact 
        /// </summary>
        /// <param name="contactViewModel">contactViewModel</param>
        /// <returns>BaseViewModel</returns>
        public async Task<BaseViewModel> AddContact(ContactViewModel contactViewModel)
        {

            return await new Contact()
            {
                Id = Guid.NewGuid(),
                FirstName = contactViewModel.FirstName,
                LastName = contactViewModel.LastName,
                Discription = contactViewModel.Discription,
                Email = contactViewModel.Email,
                IsDeleted = contactViewModel.IsDeleted,
                IsActive = contactViewModel.IsActive

            }.Save();


        }

        /// <summary>
        /// Edit Contacts
        /// </summary>
        /// <param name="contactViewModel">contactViewModel</param>
        /// <returns>BaseViewModel</returns>
        public async Task<BaseViewModel> EditContact(ContactViewModel contactViewModel)
        {
            return await new Contact()
            {
                Id = contactViewModel.Id,
                FirstName = contactViewModel.FirstName,
                LastName = contactViewModel.LastName,
                Discription = contactViewModel.Discription,
                Email = contactViewModel.Email,
                IsDeleted = contactViewModel.IsDeleted,
                IsActive = contactViewModel.IsActive

            }.Update();
        }

        /// <summary>
        /// Get All Contact List
        /// </summary>
        /// <returns>List of Contacts</returns>
        public async Task<IList<Contact>> GetAllContacts()
        {
            return await new Contact().GetAllContacts();
        }

        public Task<Contact> GetContactById(Guid id)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Delete Contact
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public async Task<BaseViewModel> DeleteContact(BaseViewModel viewModel)
        {
            return await new Contact().DeleteContact(viewModel);
        }
    }
}
