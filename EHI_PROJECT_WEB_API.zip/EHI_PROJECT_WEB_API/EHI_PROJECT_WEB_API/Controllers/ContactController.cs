﻿using EHI_PROJECT_WEB_API.Model;
using EHI_PROJECT_WEB_API.Services;
using EHI_PROJECT_WEB_API.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EHI_PROJECT_WEB_API.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class ContactController : ControllerBase
    {

        private readonly IContactService _contactService;
        private readonly ILogger<ContactController> _logger;

        #region Constructors

        public ContactController(IContactService contactService, ILogger<ContactController> logger)
        {
            _contactService = contactService;
            _logger = logger;
        }

        #endregion

        /// <summary>
        /// Get All Contact List
        /// </summary>
        /// <returns>List of Contacts</returns>
        [HttpGet]
        public async Task<IList<Contact>> Get()
        {
            try
            {
                return await _contactService.GetAllContacts();
            }
            catch (System.Exception)
            {
                return null;
            }

        }

        /// <summary>
        /// Save Contact
        /// </summary>
        /// <param name="viewModel"> view Model</param>
        /// <returns>BaseViewModel</returns>
        [HttpPost]
        public async Task<BaseViewModel> AddContact(ContactViewModel viewModel)
        {
            try
            {
                return await _contactService.AddContact(viewModel);
            }
            catch (System.Exception ex)
            {
                return new BaseViewModel() { Id = viewModel.Id, Message = ex.Message };
            }

        }

        /// <summary>
        /// Edit Contact
        /// </summary>
        /// <param name="viewModel">viewModel</param>
        /// <returns>EditContact</returns>
        [HttpPut]
        public async Task<BaseViewModel> EditContact(ContactViewModel viewModel)
        {
            try
            {
                return await _contactService.EditContact(viewModel);
            }
            catch (System.Exception ex)
            {
                return new BaseViewModel() { Id = viewModel.Id, Message = ex.Message };
            }
        }

        /// <summary>
        /// Edit Contact
        /// </summary>
        /// <param name="viewModel">viewModel</param>
        /// <returns>EditContact</returns>
        [HttpDelete]
        public async Task<BaseViewModel> DeleteContact(BaseViewModel viewModel)
        {
            try
            {
                return await _contactService.DeleteContact(viewModel);
            }
            catch (System.Exception ex)
            {
                return new BaseViewModel() { Id = viewModel.Id, Message = ex.Message };
            }
        }
    }
}
